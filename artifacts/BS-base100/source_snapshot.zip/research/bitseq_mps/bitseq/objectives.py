"""Small configuration adapters around original GFlowNet objective implementations."""

from gfn.estimators import DiscretePolicyEstimator
from gfn.gflownet import TBGFlowNet
from gfn.utils.modules import UniformModule


def make_canonical_tb(env, forward_module):
    """Configure the original extensive squared TB loss, no reference or reward exponentiation."""
    pf = DiscretePolicyEstimator(forward_module, n_actions=env.n_actions)
    pb = DiscretePolicyEstimator(
        UniformModule(output_dim=env.n_actions - 1, input_dim=env.words_per_seq),
        n_actions=env.n_actions,
        is_backward=True,
    )
    return TBGFlowNet(
        pf=pf,
        pb=pb,
        init_logZ=0.0,
        log_reward_clip_min=-float("inf"),
        debug=True,
    )
