"""Verified denoising loss primitives; source mask/scoring functions are reused."""

import torch

from tdlm.mdm import SurrogateCfg, draw_masks, score_from_masks


def draw_pretraining_masks(batch: int, generator: torch.Generator):
    cfg = SurrogateCfg(n_replicates=1, scheme="uniform_l", scale="extensive")
    return draw_masks(6, batch, cfg, generator, "cpu")[0][0]


def pretraining_loss(model, y, masks):
    if (
        y.ndim != 2
        or y.shape[1] != 6
        or masks.shape != y.shape
        or masks.dtype != torch.bool
    ):
        raise ValueError("word batch and Boolean masks[B,6] required")
    if y.dtype not in (torch.int32, torch.int64) or bool(((y < 0) | (y > 3)).any()):
        raise ValueError("only full four-word terminal boards are denoising labels")
    if bool((masks.sum(1) == 0).any()):
        raise ValueError("pretraining mask must be nonempty")
    prompt = torch.full((len(y), 1), 5, dtype=torch.long, device=y.device)
    weights = 6 / masks.sum(1).float()
    return -score_from_masks(model, prompt, y, [(masks, weights)]).mean()
