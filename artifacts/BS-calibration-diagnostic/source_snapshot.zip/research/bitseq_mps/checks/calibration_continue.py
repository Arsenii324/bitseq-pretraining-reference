"""Registered four-arm Q1 continuation; same parent weights/Adam/context RNGs.

Not primary RL or silently resumed original run. Source captured once for the
campaign, allowing unrelated later implementation edits without hot loading.
"""

import hashlib
import json
from pathlib import Path
import time
import zipfile

import numpy as np
import torch

from bitseq.artifacts import archive_sources,save_checkpoint,source_identity,write_json
from bitseq.model import make_denoiser
from bitseq.oracle import FiniteGraph,task_distribution,teacher_table
from bitseq.run import _evaluate,_resources,_check_resources
from bitseq.train import draw_pretraining_masks,pretraining_loss,soft_pretraining_loss


def main():
    root=Path(__file__).resolve().parents[3]
    output=root/'research/bitseq_mps/runs/BS-calibration-diagnostic'
    output.mkdir(parents=True,exist_ok=False)
    parent=root/'research/bitseq_mps/runs/BS-base100/ckpt_006000.pt'
    checkpoint=torch.load(parent,map_location='cpu',weights_only=True)
    identity=source_identity();archive_sources(output,identity)
    with zipfile.ZipFile(output/'source_snapshot.zip','a') as archive:
        archive.write(__file__,'research/bitseq_mps/checks/calibration_continue.py')
    campaign=dict(source=identity,entrypoint_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  parent=str(parent),parent_sha256=hashlib.sha256(parent.read_bytes()).hexdigest(),
                  protocol='reports/04_PRETRAINING_DIAGNOSTIC_PROTOCOL.md',steps=2000,batch=256,eval_every=250)
    write_json(output/'campaign.json',campaign)
    graph=FiniteGraph();truth=task_distribution(graph,12)
    teacher,_=teacher_table(graph,truth['q'])
    datawords=torch.tensor(graph.boards[graph.terminals]);weights=torch.tensor(truth['q'])
    results={}
    for kind,lr in [('hard',6e-4),('hard',6e-5),('soft',6e-4),('soft',6e-5)]:
        name=kind+('-high' if lr==6e-4 else '-low')
        directory=output/name;directory.mkdir()
        model=make_denoiser(100).to('mps');model.load_state_dict(checkpoint['model'])
        optimizer=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=0.)
        optimizer.load_state_dict(checkpoint['optimizer'])
        for group in optimizer.param_groups:group['lr']=lr
        data=torch.Generator();data.set_state(checkpoint['generators']['data'])
        maskgen=torch.Generator();maskgen.set_state(checkpoint['generators']['mask'])
        initial=_resources(directory)
        manifest=dict(**campaign,arm=name,lr=lr,estimator=kind,pid=__import__('os').getpid(),initial_resources=initial,
                      parent_training_steps=6000,local_training_steps=0)
        write_json(directory/'manifest.json',manifest)
        first_eligible=None;started=time.monotonic();norms=[]
        try:
            for step in range(1,2001):
                indices=torch.multinomial(weights,256,replacement=True,generator=data)
                y=datawords[indices].to('mps');mask=draw_pretraining_masks(256,maskgen).to('mps')
                optimizer.zero_grad(set_to_none=True);model.train()
                if kind=='hard':loss=pretraining_loss(model,y,mask)
                else:
                    boards=torch.where(mask,-1,y)
                    rows=graph.index(boards.cpu().numpy())
                    targets=torch.tensor(np.exp(teacher[rows]),dtype=torch.float32,device='mps')
                    loss=soft_pretraining_loss(model,boards,targets)
                if not torch.isfinite(loss):raise RuntimeError('nonfinite diagnostic loss')
                loss.backward();norm=torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True)
                optimizer.step();norms.append(float(norm.detach().cpu()))
                if step%25==0:_check_resources(_resources(directory),initial)
                if step%250==0:
                    evaluation=_evaluate(model,graph,truth,directory,step)
                    metadata=dict(source_hash=identity['hash'],arm=name,step=step,parent_training_steps=6000,
                                  samples=step*256,optimizer_steps=step,lr=lr,estimator=kind)
                    save_checkpoint(directory/f'ckpt_{step:06d}.pt',model,optimizer,{'data':data,'mask':maskgen},metadata)
                    result=dict(**metadata,evaluation=evaluation,elapsed_seconds=time.monotonic()-started,
                                clipping_fraction=float(np.mean(np.array(norms)>1)),mean_preclip_norm=float(np.mean(norms)))
                    if step%500==0 and evaluation['calibrated'] and first_eligible is None:
                        first_eligible=step
                    result['first_primary_eligible_step']=first_eligible
                    write_json(directory/'progress.json',result,overwrite=True)
                    print(json.dumps(dict(arm=name,step=step,calibrated=evaluation['calibrated'],
                                          tv_ar=evaluation['decoders']['ar']['tv_prior'],
                                          tv_random=evaluation['decoders']['random']['tv_prior'],
                                          decoder_tv=evaluation['decoder_tv'],excess_per_word=evaluation['denoising']['per_word_excess'])),flush=True)
            results[name]=result
        except Exception as exc:
            write_json(directory/'failure.json',dict(error=repr(exc),local_step=step))
            raise
        del optimizer,model;torch.mps.empty_cache()
    write_json(output/'results.json',results)


if __name__=='__main__':main()
